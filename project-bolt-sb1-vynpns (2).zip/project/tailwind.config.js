/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          100: '#fce7f3', // magenta-100
          500: '#d946ef', // magenta-500
          600: '#c026d3', // magenta-600
          700: '#a21caf', // magenta-700
        }
      }
    },
  },
  plugins: [],
};