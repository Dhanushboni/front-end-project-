import React from 'react';
import { Package, Calendar, Users, Clock } from 'lucide-react';

const packages = [
  {
    id: 1,
    destination: 'Tirupati',
    price: 5000,
    duration: '3 Days / 2 Nights',
    highlights: ['Temple Darshan', 'Local Sightseeing', 'Accommodation', 'Transfers'],
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&q=80'
  },
  {
    id: 2,
    destination: 'Visakhapatnam',
    price: 7000,
    duration: '4 Days / 3 Nights',
    highlights: ['Beach Activities', 'City Tour', 'Accommodation', 'Transfers'],
    image: 'https://images.unsplash.com/photo-1596402184320-417e7178b2cd?auto=format&fit=crop&q=80'
  },
  {
    id: 3,
    destination: 'Araku Valley',
    price: 8000,
    duration: '3 Days / 2 Nights',
    highlights: ['Coffee Plantations', 'Tribal Village Visit', 'Accommodation', 'Transfers'],
    image: 'https://images.unsplash.com/photo-1599939571322-792a326991f2?auto=format&fit=crop&q=80'
  },
  {
    id: 4,
    destination: 'Amaravati',
    price: 6000,
    duration: '2 Days / 1 Night',
    highlights: ['Buddhist Monuments', 'River Cruise', 'Accommodation', 'Transfers'],
    image: 'https://images.unsplash.com/photo-1623677375459-4d656ab3c71b?auto=format&fit=crop&q=80'
  }
];

export default function Packages() {
  return (
    <section id="packages" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Packages & Deals</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {packages.map((pkg) => (
            <div key={pkg.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow border border-gray-200">
              <div className="relative h-48">
                <img
                  src={pkg.image}
                  alt={pkg.destination}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-primary-600 text-white px-3 py-1 rounded-full">
                  From ₹{pkg.price}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-4">{pkg.destination} Package</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center text-gray-600">
                    <Clock className="h-5 w-5 mr-2 text-primary-600" />
                    <span>{pkg.duration}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-start">
                      <Package className="h-5 w-5 mr-2 text-primary-600 mt-1" />
                      <ul className="text-gray-600">
                        {pkg.highlights.map((highlight, index) => (
                          <li key={index} className="text-sm">{highlight}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                
                <button className="w-full mt-6 bg-primary-600 text-white py-2 px-4 rounded-md hover:bg-primary-700 transition-colors flex items-center justify-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}