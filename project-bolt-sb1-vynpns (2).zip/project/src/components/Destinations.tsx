import React from 'react';
import { MapPin } from 'lucide-react';

const destinations = [
  {
    id: 1,
    name: 'Tirupati',
    description: 'Home to the famous Venkateswara Temple, one of the most visited religious sites in the world.',
    image: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&q=80',
  },
  {
    id: 2,
    name: 'Visakhapatnam',
    description: 'A coastal paradise with beautiful beaches, hills, and modern urban infrastructure.',
    image: 'https://images.unsplash.com/photo-1596402184320-417e7178b2cd?auto=format&fit=crop&q=80',
  },
  {
    id: 3,
    name: 'Araku Valley',
    description: 'A hill station known for its coffee plantations, tribal culture, and pleasant climate.',
    image: 'https://images.unsplash.com/photo-1599939571322-792a326991f2?auto=format&fit=crop&q=80',
  },
  {
    id: 4,
    name: 'Amaravati',
    description: 'The ancient Buddhist site and current capital region of Andhra Pradesh.',
    image: 'https://images.unsplash.com/photo-1623677375459-4d656ab3c71b?auto=format&fit=crop&q=80',
  },
];

export default function Destinations() {
  return (
    <section id="destinations" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Popular Destinations</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {destinations.map((destination) => (
            <div key={destination.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-2">
                  <MapPin className="h-5 w-5 text-primary-600 mr-2" />
                  <h3 className="text-xl font-semibold">{destination.name}</h3>
                </div>
                <p className="text-gray-600">{destination.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}