import React from 'react';
import { Music, Palette, Users } from 'lucide-react';

const culturalAspects = [
  {
    icon: <Music className="h-8 w-8" />,
    title: 'Classical Arts',
    description: 'Rich traditions of Kuchipudi dance, Carnatic music, and folk performances.',
  },
  {
    icon: <Palette className="h-8 w-8" />,
    title: 'Handicrafts',
    description: 'Famous for Kalamkari art, handloom textiles, and intricate temple sculptures.',
  },
  {
    icon: <Users className="h-8 w-8" />,
    title: 'Festivals',
    description: 'Vibrant celebrations of Sankranti, Ugadi, and various temple festivals.',
  },
];

export default function Culture() {
  return (
    <section id="culture" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Cultural Heritage</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {culturalAspects.map((aspect, index) => (
            <div key={index} className="text-center">
              <div className="inline-block p-4 bg-primary-100 rounded-full text-primary-600 mb-4">
                {aspect.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{aspect.title}</h3>
              <p className="text-gray-600">{aspect.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}