import React from 'react';
import { ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <div 
      id="home" 
      className="relative h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80')`,
      }}
    >
      <div className="absolute inset-0 bg-black/40" /> {/* Darker overlay for better text contrast */}
      
      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center text-white px-4">
        <h1 className="text-5xl md:text-7xl font-bold text-center mb-6">
          Welcome to Andhra Pradesh
        </h1>
        <p className="text-xl md:text-2xl text-center mb-8 max-w-3xl">
          Discover the land of ancient temples, pristine beaches, and rich cultural heritage
        </p>
        <a
          href="#destinations"
          className="bg-white text-primary-600 hover:bg-gray-100 px-8 py-3 rounded-full text-lg font-semibold transition-colors transform hover:scale-105 duration-200"
        >
          Explore Destinations
        </a>
        
        <div className="absolute bottom-8 animate-bounce">
          <ChevronDown size={32} />
        </div>
      </div>
    </div>
  );
}